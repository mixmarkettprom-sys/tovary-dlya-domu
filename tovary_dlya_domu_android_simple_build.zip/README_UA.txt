СПРОЩЕНИЙ СПОСІБ ЗБІРКИ APK

1. Завантаж у корінь GitHub-репозиторію файл tovary_dlya_domu_source.zip.
2. Створи файл .github/workflows/build-apk.yml через GitHub -> Add file -> Create new file.
3. Скопіюй у нього текст із BUILD_WORKFLOW_UA.txt.
4. Збережи файл (Commit changes).
5. Відкрий Actions -> Build Android APK -> Run workflow.
6. Після завершення відкрий виконаний workflow і в Artifacts завантаж TovaryDlyaDomu-debug-apk.
